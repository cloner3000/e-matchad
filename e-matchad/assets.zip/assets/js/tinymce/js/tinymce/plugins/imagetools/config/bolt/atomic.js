configure({
  configs: [
    './test.js',
    './prod.js'
  ]
});
